这是一份脱敏后的CDN目录检查变更材料。

contracts/indexed_release_policy.json记录Job字段和失败策略。
inventory/catalog_partitions.csv记录目录分区、发布层级和启用状态。
inventory/release_capacity.csv记录维护窗口的并发和覆盖要求。
starter/job.yaml是当前普通Job。
change_request.txt说明变更原因和岗位分工。

停用目录不进入本次发布范围。目录名称、地址和镜像来自版本组交接清单，访问凭据没有随包导出。
