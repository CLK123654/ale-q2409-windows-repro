# CDN目录检查变更说明

维护窗口为周三。影响范围是edge-assets中的cdn-catalog-check Job及其目录映射。

发布包把普通Job改成按启用目录分片的Indexed Job，停用目录不进入ConfigMap。固定镜像、逐索引回退、永久错误、基础设施中断和核心市场successPolicy均按合同与窗口容量设置。

回滚材料是输入包中的starter/job.yaml。平台组负责发布包评审，维护窗值班负责现场应用、回滚准备和运行观察。
